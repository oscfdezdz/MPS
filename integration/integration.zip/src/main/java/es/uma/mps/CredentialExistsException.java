package es.uma.mps;

public class CredentialExistsException extends RuntimeException {
}
